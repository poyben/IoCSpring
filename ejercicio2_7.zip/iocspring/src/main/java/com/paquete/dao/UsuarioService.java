package com.paquete.dao;

public interface UsuarioService {

	public void inserta();
	
}
