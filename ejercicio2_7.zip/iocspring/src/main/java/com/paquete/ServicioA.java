package com.paquete;

import org.springframework.stereotype.Service;

@Service
public class ServicioA {

	public String getMensaje() {
		return "Enviando mensajede ServicioA";
	}
	
}
